#include "aboutdlg.h"

aboutdlg::aboutdlg(QDialog* parent)
    : QDialog(parent)
{
    ui.setupUi(this);
}

aboutdlg::~aboutdlg()
{

}
