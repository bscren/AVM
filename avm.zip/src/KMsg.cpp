#include "KMsg.h"

namespace kmod {

	KMsg<MatTimeStamp>	g_ImgbufList[10];
}